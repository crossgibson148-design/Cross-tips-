# Cross Tips — Flutter Android starter

Cross Tips is a first working source-code version of a football match prediction app.

## Included
- Manual match entry with home/away teams, competition and recent goals-for/goals-against averages.
- Simple independent Poisson-goal model producing estimated 1X2, Over 1.5/2.5/3.5 and BTTS Yes probabilities.
- Daily dashboard, match list, local history and final-score recording.
- Local persistence using `shared_preferences`.
- Optional automatic fixture import from football-data.org using a user-supplied API token. Imported fixtures use example default team averages until the user edits/re-enters actual statistics.

## Run on Android
1. Install Flutter SDK and Android Studio (Android SDK + platform tools).
2. Unzip this folder.
3. In this folder run:
   ```bash
   flutter create . --platforms=android
   flutter pub get
   flutter run
   ```
4. To build an installable APK:
   ```bash
   flutter build apk --release
   ```
   APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Automatic fixtures setup
Create an API token with football-data.org, open the app's settings icon, and paste the token. The provider's free plan and competition coverage may be limited. This starter imports fixtures only; it does not automatically retrieve historical team statistics, injuries, line-ups, odds or results.

## Important model limitation
The prediction model is a transparent baseline, not a trained or validated betting model. Its probabilities depend on the averages entered and should not be treated as guaranteed outcomes or financial advice. Validate predictions against a sizeable historical dataset before relying on them.
